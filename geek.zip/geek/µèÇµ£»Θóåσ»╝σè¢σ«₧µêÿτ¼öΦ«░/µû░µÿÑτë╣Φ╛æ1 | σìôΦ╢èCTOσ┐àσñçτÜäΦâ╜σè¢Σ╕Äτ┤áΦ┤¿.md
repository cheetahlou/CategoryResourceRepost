
你好，我是《技术领导力实战笔记》专栏的主编成敏，今天是除夕，先在这里祝你除夕快乐，身体健康，万事如意！

从2018年4月16号，《技术领导力实战笔记》专栏更新第一篇文章开始，我们已经与你一起度过了9个多月的时光，更新了210篇文章，走过了专栏3/4的路程。

在这9个多月里，我们邀请到了近百位CEO、CTO、技术VP等技术领导者来分享他们的实践与经验，话题涉及技术领导者的核心能力、高效技术团队的打造、高效研发流程的建设、技术团队的考核与激励、技术团队文化的建设、技术人才的选育用留等多个方向。

这些文章虽有序但却分散在全年的专栏中，恰逢新春假期，我特别整理了5个热门的主题的直达专辑，以便您按照主题领域来回顾。你可以点击知识卡，跳转到你最想看的那篇文章，温故而知新。

今天专辑的主题是“卓越CTO必备的能力与素质”，希望你看完之后能有所收获，也欢迎留言选出你最喜欢的文章，或是分享你对于CTO必备能力与素质的观点。

[<img src="https://static001.geekbang.org/resource/image/75/88/75fadc34ed0fe3ad712b118d36890a88.jpg" alt="">](https://time.geekbang.org/column/article/6257)<br>
[<img src="https://static001.geekbang.org/resource/image/7b/42/7b3800353526c0b11ee12984bd913e42.jpg" alt="">](https://time.geekbang.org/column/article/6374)<br>
[<img src="https://static001.geekbang.org/resource/image/91/f3/91e8a7c392886eed5818e57d839fe4f3.jpg" alt="">](https://time.geekbang.org/column/article/6399)<br>
[<img src="https://static001.geekbang.org/resource/image/fd/fd/fd2c65875e853d80592a45ab5f30d7fd.jpg" alt="">](https://time.geekbang.org/column/article/6581)<br>
[<img src="https://static001.geekbang.org/resource/image/65/fb/6573a0c475e2dcbe9e4cac0afdd5a8fb.jpg" alt="">](https://time.geekbang.org/column/article/6585)<br>
[<img src="https://static001.geekbang.org/resource/image/cb/04/cbbb2f888d5901ded73f3140d669e904.jpg" alt="">](https://time.geekbang.org/column/article/6656)<br>
[<img src="https://static001.geekbang.org/resource/image/a4/67/a4674df83038f293aaa29e69ce476467.jpg" alt="">](https://time.geekbang.org/column/article/9426)<br>
[<img src="https://static001.geekbang.org/resource/image/36/ef/36e080389c6bdd98c4471382f86008ef.jpg" alt="">](https://time.geekbang.org/column/article/10154)<br>
[<img src="https://static001.geekbang.org/resource/image/86/03/86916db73d10f80ca26147aa06963903.jpg" alt="">](https://time.geekbang.org/column/article/12246)<br>
[<img src="https://static001.geekbang.org/resource/image/3f/bc/3f0a4e2e6ab86ae2d9ba042f32d4efbc.jpg" alt="">](https://time.geekbang.org/column/article/12378)<br>
[<img src="https://static001.geekbang.org/resource/image/9c/87/9c19f06035aac28dd1f8b57468f62487.jpg" alt="">](https://time.geekbang.org/column/article/74338)<br>
[<img src="https://static001.geekbang.org/resource/image/4c/be/4ccb6db91735b0184e2122ca0a2e8bbe.jpg" alt="">](https://time.geekbang.org/column/article/75341)<br>
[<img src="https://static001.geekbang.org/resource/image/bd/21/bd33e29204f5197b4ea8c952e3774621.jpg" alt="">](https://time.geekbang.org/column/article/79774)<br>
[<img src="https://static001.geekbang.org/resource/image/3a/1c/3a2a5f71b8b7090991544156f447ed1c.jpg" alt="">](https://time.geekbang.org/column/article/6297)<br>
[<img src="https://static001.geekbang.org/resource/image/23/79/23ce1ca0b690f0e142f7aed0029bb979.jpg" alt="">](https://time.geekbang.org/column/article/42080)
